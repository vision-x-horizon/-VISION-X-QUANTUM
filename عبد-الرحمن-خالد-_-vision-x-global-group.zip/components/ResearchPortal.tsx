
import React, { useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Loader2, Sparkles, X, BrainCircuit, Landmark, ShieldCheck, Zap, Presentation, BarChart, Binary } from 'lucide-react';

interface ResearchPortalProps {
  onResearchAdded: (research: any) => void;
  onClose: () => void;
}

export const ResearchPortal: React.FC<ResearchPortalProps> = ({ onResearchAdded, onClose }) => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const generateResearch = async () => {
    if (!input.trim()) return;
    setLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `أنت "المحلل الاستراتيجي SAI" لمجموعة VISION-X-GROUP. 
      أنت ملم تماماً بأبحاث المؤسس عبد الرحمن خالد، خاصة:
      1. UDPM-4.2 (الإطار الكمي الموحد): معادلات الكثافة الإدراكية (M)، التماسك العصبي (C)، والانحناء الإدراكي (κ).
      2. FWFI (الاتصال عبر تداخل الحقل الموجي): مبدأ "الاتصال الشبح"، كفاءة الطاقة 95%، وسرعات 1 Tbps.
      
      المهمة: قم بتحليل فكرة المستخدم وربطها بهذه البروتوكولات العلمية الحقيقية. 
      صغ عرضاً تقديمياً استراتيجياً (Strategic Keynote) باللغة العربية العلمية الرصينة.

      المتطلبات:
      1. Title: عنوان سيادي وعلمي.
      2. Summary: ملخص استراتيجي يوضح القيمة المضافة للبنية التحتية (مثل Google Cloud أو Azure).
      3. Category: (Quantum Dynamics, 6G+ FWFI, Reality Engineering, Neural Sync).
      4. Innovation Value: (1-100).
      5. Market Need: الاحتياج العالمي الملح.

      النص الخام للفكرة: ${input}`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              summary: { type: Type.STRING },
              category: { type: Type.STRING },
              innovationValue: { type: Type.NUMBER },
              marketNeed: { type: Type.STRING }
            },
            required: ["title", "summary", "category", "innovationValue", "marketNeed"]
          }
        }
      });

      const result = JSON.parse(response.text);
      onResearchAdded({
        ...result,
        id: Date.now(),
        date: new Date().toLocaleDateString('ar-EG')
      });
      setInput('');
      onClose();
    } catch (error) {
      console.error("Gemini Error:", error);
      alert("خطأ في الاتصال بنواة SAI. يرجى التأكد من استقرار بروتوكول UDPM.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/98 backdrop-blur-3xl"
    >
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
        className="bg-[#161821] border border-indigo-500/30 w-full max-w-4xl rounded-[4rem] overflow-hidden shadow-[0_0_150px_rgba(99,102,241,0.15)]"
      >
        <div className="p-12 border-b border-white/5 flex justify-between items-center bg-gradient-to-r from-indigo-500/5 to-transparent">
          <div className="flex items-center gap-6">
            <div className="w-20 h-20 bg-indigo-500/20 rounded-3xl flex items-center justify-center text-indigo-400">
              <Binary size={40} />
            </div>
            <div className="text-right">
              <h2 className="text-3xl font-black">تحليل الجدوى السيادية</h2>
              <p className="text-xs text-indigo-400 font-mono uppercase tracking-[0.3em]">SAI Strategic Interface v2.0</p>
            </div>
          </div>
          <button onClick={onClose} className="p-4 bg-white/5 rounded-full hover:bg-white/10 transition">
            <X size={32} />
          </button>
        </div>

        <div className="p-16 text-right">
          <div className="mb-12 p-8 bg-indigo-600/5 border border-indigo-500/20 rounded-3xl flex items-start gap-6 flex-row-reverse">
            <ShieldCheck className="text-indigo-400 mt-1 shrink-0" size={24}/>
            <p className="text-lg text-gray-400 leading-relaxed">
              أدخل المفهوم التقني المراد فحصه. سيقوم المحلل <span className="text-white font-bold">SAI Gemini</span> بربط فكرتك بأسس <span className="text-indigo-400">UDPM-4.2</span> و <span className="text-indigo-400">FWFI</span> لتقدير الجدوى المعمارية.
            </p>
          </div>
          
          <textarea 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="مثال: إنشاء شبكة اتصالات فضائية بين الكواكب تعتمد على رنين الغلاف الجوي كبوابة اتصال..."
            className="w-full h-64 bg-black/40 border border-white/5 rounded-[2.5rem] p-10 text-white placeholder:text-gray-700 focus:border-indigo-500/50 outline-none transition-all resize-none text-2xl font-medium text-right"
          />
          
          <div className="mt-12 flex justify-end">
            <button 
              disabled={loading || !input}
              onClick={generateResearch}
              className="px-16 py-8 bg-indigo-600 text-white rounded-[2rem] font-black flex flex-row-reverse items-center gap-6 hover:bg-white hover:text-black transition-all shadow-2xl disabled:opacity-20"
            >
              {loading ? <Loader2 className="animate-spin" /> : <Sparkles size={28} />}
              <span className="text-2xl">{loading ? "جاري المعالجة الإدراكية..." : "توليد العرض الاستراتيجي"}</span>
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};
