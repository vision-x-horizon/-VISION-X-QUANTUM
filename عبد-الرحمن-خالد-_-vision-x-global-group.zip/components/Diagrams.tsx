
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React from 'react';
import { motion } from 'framer-motion';

interface ArmCardProps {
  icon: React.ReactNode;
  title: string;
  desc: string;
  points: string[];
  footer?: string;
  borderColor: string;
  hoverColor: string;
  shadowColor: string;
  titleColor: string;
}

export const ArmCard: React.FC<ArmCardProps> = ({ 
  icon, title, desc, points, footer, borderColor, hoverColor, shadowColor, titleColor 
}) => {
  return (
    <motion.div 
      whileHover={{ y: -8 }}
      className={`bg-[#161821] rounded-[2.5rem] p-10 border ${borderColor} ${hoverColor} ${shadowColor} transition-all duration-300 shadow-xl cursor-pointer flex flex-col h-full`}
    >
      <div className="flex items-center gap-5 mb-8">
        <div className="p-3 bg-white/5 rounded-2xl">
          {icon}
        </div>
        <h3 className={`text-2xl sm:text-3xl font-black ${titleColor} drop-shadow-lg leading-tight`}>{title}</h3>
      </div>
      <p className="text-lg font-bold mb-8 text-gray-200 leading-relaxed">
        {desc}
      </p>
      <ul className="space-y-4 text-base text-gray-400 flex-grow">
        {points.map((point, i) => (
          <li key={i} className="flex items-start gap-3">
            <span className="text-indigo-400 mt-1 font-black text-xl leading-none">◆</span>
            <span className="leading-relaxed font-medium">{point}</span>
          </li>
        ))}
      </ul>
      {footer && (
        <div className={`font-black ${titleColor} mt-10 pt-6 border-t border-white/5 text-sm uppercase tracking-tighter`}>
          ... {footer}
        </div>
      )}
    </motion.div>
  );
};

interface ProjectCardProps {
  number: string;
  icon: string;
  title: string;
  target: string;
  points: string[];
  color: 'cyan' | 'blue' | 'indigo';
}

export const ProjectCard: React.FC<ProjectCardProps> = ({ number, icon, title, target, points, color }) => {
  const colorMap = {
    cyan: 'border-t-cyan-400 hover:shadow-cyan-500/30 text-cyan-400',
    blue: 'border-t-blue-400 hover:shadow-blue-500/30 text-blue-400',
    indigo: 'border-t-indigo-400 hover:shadow-indigo-500/30 text-indigo-400',
  };

  return (
    <motion.div 
      whileHover={{ y: -6 }}
      className={`border-t-8 ${colorMap[color]} bg-[#161821] p-10 rounded-[3rem] shadow-2xl transition-all duration-300`}
    >
      <h3 className="text-2xl sm:text-3xl font-black mb-6 leading-relaxed flex items-center gap-3">
        <span className="text-white/20 font-mono text-4xl">{number}</span>
        <span>{icon} {title}</span>
      </h3>
      <div className="mb-8">
        <div className="text-xs font-black uppercase text-indigo-400 mb-2 opacity-60 tracking-widest">Target Objective</div>
        <p className="text-gray-100 font-bold leading-relaxed text-lg">
          {target}
        </p>
      </div>
      <ul className="space-y-4 text-gray-400">
        {points.map((point, i) => (
          <li key={i} className="flex items-start gap-4 pr-2">
            <span className={`${colorMap[color].split(' ')[2]} mt-1.5 text-2xl font-black leading-none`}>◆</span>
            <span className="leading-relaxed font-medium">{point}</span>
          </li>
        ))}
      </ul>
    </motion.div>
  );
};
